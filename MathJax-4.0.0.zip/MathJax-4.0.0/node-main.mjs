import './node-main-setup.mjs';
import {MathJax} from './node-main.js';
export default MathJax;
export const init = MathJax.init;
