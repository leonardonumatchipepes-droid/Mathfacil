if (!global.MathJax) global.MathJax = {};

global.MathJax.__dirname = __dirname;

module.exports = require('./node-main.js').MathJax;
